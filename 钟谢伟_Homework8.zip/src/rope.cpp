#include <iostream>
#include <vector>

#include "CGL/vector2D.h"

#include "mass.h"
#include "rope.h"
#include "spring.h"

namespace CGL {

    Rope::Rope(Vector2D start, Vector2D end, int num_nodes, float node_mass, float k, vector<int> pinned_nodes)
    {
        // TODO (Part 1): Create a rope starting at `start`, ending at `end`, and containing `num_nodes` nodes.
        Vector2D start2end = end - start;
        double length = start2end.norm();
        Vector2D dir = start2end.unit();
        double stepLength = length / (num_nodes-1);

        for (int i=0; i<num_nodes; ++i)
        {
            Vector2D position = start + i * stepLength * dir;
            Mass* mass = new Mass(position, node_mass, false);
            masses.push_back(mass);
        }

        for (int i=0; i<num_nodes-1; ++i)
        {
            Spring* spring = new Spring(masses[i], masses[i+1], k);
            springs.push_back(spring);
        }

//        Comment-in this part when you implement the constructor
       for (auto &i : pinned_nodes) 
       {
           masses[i]->pinned = true;
       }
    }

    void Rope::simulateEuler(float delta_t, Vector2D gravity)
    {
        for (auto &s : springs)
        {
            // TODO (Part 2): Use Hooke's law to calculate the force on a node
            Vector2D force_a2b = s->k * 
                (s->m2->position - s->m1->position)/(s->m2->position - s->m1->position).norm() *
                ((s->m2->position - s->m1->position).norm() - s->rest_length);
            s->m1->forces += force_a2b;
            s->m2->forces += -force_a2b;
        }

        for (auto &m : masses)
        {
            if (!m->pinned)
            {
                float damping_factor = 0.00005;

                // TODO (Part 2): Add the force due to gravity, then compute the new velocity and position
                Vector2D force = m->forces + gravity;
                Vector2D a = force / m->mass;
                Vector2D new_velocity = m->velocity + a * delta_t;

                // 显式
                // Vector2D new_position = m->position + m->velocity * delta_t;

                // 半隐式欧拉
                Vector2D new_position = m->position + new_velocity * delta_t;

                m->velocity = new_velocity;
                m->position = new_position;

                // TODO (Part 2): Add global damping
                m->velocity = (1-damping_factor)*m->velocity;
            }

            // Reset all forces on each mass
            m->forces = Vector2D(0, 0);
        }
    }

    void Rope::simulateVerlet(float delta_t, Vector2D gravity)
    {
        for (auto &s : springs)
        {
            // TODO (Part 3): Simulate one timestep of the rope using explicit Verlet （solving constraints)
            Vector2D m22m1 = s->m1->position - s->m2->position;
            float constraint = m22m1.norm() - s->rest_length;
            Vector2D delta_m1p = -(1. / s->m1->mass * constraint) / (1. / s->m1->mass + 1. / s->m2->mass) * m22m1 / m22m1.norm();
            Vector2D delta_m2p = (1. / s->m2->mass * constraint) / (1. / s->m1->mass + 1. / s->m2->mass) * m22m1 / m22m1.norm();
            if (!s->m1->pinned) s->m1->position += delta_m1p;
            if (!s->m2->pinned) s->m2->position += delta_m2p;
        }

        for (auto &m : masses)
        {
            if (!m->pinned)
            {
                float damping_factor = 0.00005;

                Vector2D temp_position = m->position;
                // TODO (Part 3.1): Set the new position of the rope mass
                Vector2D a = gravity / m->mass;

                Vector2D new_position = m->position + (1 - damping_factor)*(m->position - m->last_position) + a*delta_t*delta_t;

                m->last_position = temp_position;
                m->position = new_position;
            }
        }
    }
}
