完成了所有的得分点，结果图在image文件夹中。



## 函数功能简单描述

- `Rope::Rope`构造了绳索；
- `Rope::simulateEuler`模拟欧拉效果；
- `Rope::simulateVerlet`模拟verlet效果，在解约束条件的时候，判断，如果是pinned的，那么对位置不进行更新。



