//
// Created by Göksu Güvendiren on 2019-05-14.
//

#include "Scene.hpp"


void Scene::buildBVH() {
    printf(" - Generating BVH...\n\n");
    this->bvh = new BVHAccel(objects, 1, BVHAccel::SplitMethod::NAIVE);
}

Intersection Scene::intersect(const Ray &ray) const
{
    return this->bvh->Intersect(ray);
}

void Scene::sampleLight(Intersection &pos, float &pdf) const
{
    float emit_area_sum = 0;
    for (uint32_t k = 0; k < objects.size(); ++k) {
        if (objects[k]->hasEmit()){
            emit_area_sum += objects[k]->getArea();
        }
    }
    float p = get_random_float() * emit_area_sum;
    emit_area_sum = 0;
    for (uint32_t k = 0; k < objects.size(); ++k) {
        if (objects[k]->hasEmit()){
            emit_area_sum += objects[k]->getArea();
            if (p <= emit_area_sum){
                objects[k]->Sample(pos, pdf);
                break;
            }
        }
    }
}

bool Scene::trace(
        const Ray &ray,
        const std::vector<Object*> &objects,
        float &tNear, uint32_t &index, Object **hitObject)
{
    *hitObject = nullptr;
    for (uint32_t k = 0; k < objects.size(); ++k) {
        float tNearK = kInfinity;
        uint32_t indexK;
        Vector2f uvK;
        if (objects[k]->intersect(ray, tNearK, indexK) && tNearK < tNear) {
            *hitObject = objects[k];
            tNear = tNearK;
            index = indexK;
        }
    }


    return (*hitObject != nullptr);
}

// Implementation of Path Tracing
Vector3f Scene::castRay(const Ray &ray, int depth) const
{

#ifdef test
    Intersection rayInter = intersect(ray);
    if (rayInter.happened) {
        return Vector3f(1.0f);
    }
    else {
        return Vector3f(0.0f);
    }


    // TO DO Implement Path Tracing Algorithm here
#else
    Intersection rayInter = intersect(ray);
    Vector3f result(0.0f, 0.0f, 0.0f);
    if (rayInter.happened)
    {
        Vector3f p = rayInter.coords;
        Vector3f dir = normalize(ray.direction);
        Vector3f norm = normalize(rayInter.normal);
        if (rayInter.obj->hasEmit())
        {
            return Vector3f(1.0, 1.0, 1.0);
        }
        result = shade(p, dir, norm, rayInter.m);
    }

    return result;
#endif
}

Vector3f Scene::shade(const Vector3f& p, const Vector3f& wo, const Vector3f& normal, Material* m) const
{
    // Pesduo code:
    // shade(p, wo)
    //   sampleLight(inter, pdf_light)
    //   Get x, ws, NN, emit from inter
    //   Shoot a ray from p to x
    //   If the ray is not blocked in the middle
    //     L_dir = emit * eval(wo, ws, N) * dot(ws, N) * dot(ws, NN) / |x-p|^2 / pdf_light
    //
    //   L_indir = 0.0
    //   Test Russian Roulette with probability RussianRoulette
    //   wi = sample(wo, N)
    //   Trace a ray r(p, wi)
    //   If ray r hit a non-emitting object at q
    //     L_indir = shade(q, wi) * eval(wo, wi, N) * dot(wi, N) / pdf(wo, wi, N) / RussianRoulette
    //
    //   Return L_dir + L_indir
    Vector3f N = normal;
    N = N.normalized();

    Intersection inter;
    float pdf_light;
    sampleLight(inter, pdf_light);

    auto isEqualVector3 = [](Vector3f a, Vector3f b) -> bool {
        float epsion = 1e-6;
        return (abs(a.x - b.x) < epsion && abs(a.y - b.y) < epsion && abs(a.z - b.z) < epsion);
    };

    Vector3f L_dir(0,0,0);
    Vector3f x = inter.coords;
    Vector3f NN = inter.normal.normalized();
    Vector3f ws = x - p;
    float dis = ws.norm();
    float dis2 = dis * dis;
    ws = ws.normalized();

    Ray rayP2X(p, ws);
    Intersection interblock = intersect(rayP2X);
    float epsion = 1e-10;
    if (interblock.happened && isEqualVector3(interblock.coords, x))
    {
        if (abs(pdf_light) < epsion)
        {
            L_dir = inter.emit * m->eval(wo, ws, N) * dotProduct(ws, N) * dotProduct(-ws, NN) / dis2 / (pdf_light*1.e10) * 1.e10;
        }
        else
        {
            L_dir = inter.emit * m->eval(wo, ws, N) * dotProduct(ws, N) * dotProduct(-ws, NN) / dis2 / pdf_light;
        }
    }

    Vector3f L_indir(0,0,0);
    float pRR = get_random_float();
    if (pRR < RussianRoulette && m != nullptr)
    {
        Vector3f wi = m->sample(wo, N);
        wi = wi.normalized();

        Ray newRay(p, wi);
        Intersection wiInter = intersect(newRay);
        if (wiInter.happened && !wiInter.obj->hasEmit())
        {
            Vector3f q = wiInter.coords;
            L_indir = shade(q, wi, normalize(wiInter.normal), wiInter.m) * wiInter.m->eval(wo, wi, N) * dotProduct(wi, N) / wiInter.m->pdf(wo, wi, N) / RussianRoulette;
        }
    }

    return L_indir + L_dir;
}