完成了Path Tracing。

结果为：binary.ppm

提交的结果我的分辨率为：784*784

SPP数为：16

时间为：48 min



